const config = {
    admin: 6655707835,
    bot: {
        token: '6835186270:AAFs4BIF0lRdIbjEJcCgF1ApJwD2Uh44y2c',
        username: '@free_gifton_bot'
    },
    db: {
        url: 'mongodb://127.0.0.1:27017/test'
    },
}

export default config;
