var proxy = `185.204.3.170:40003:a1224434534z:xolop342` //HTTPS прокси для вк, каждая прокси с новой строки



module.exports = {
  proxy
};
